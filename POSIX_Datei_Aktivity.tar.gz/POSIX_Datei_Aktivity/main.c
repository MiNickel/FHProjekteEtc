// #include <stdio.h>
#include<stdbool.h>
#include <stdlib.h>      // POSIX 1003.1 - man page for malloc (posix section 3P)
#include <string.h>      // POSIX 1003.1 - man page for strlen (posix section 3P)
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>      // Kontrollfluss
#include <unistd.h>     // Schließen einer Datei, lseek()

            // #include <iostream>
             //using namespace std;

// Aufzählung für die Optionen der Ausgabe:
// 1. Bildschirmausgabe
// 2. Ausgabe in eine Datei (Kopieren einer Datei)
 enum OutputOption {
     consoleOut = 1,
     fileOut = 2
 };

///\ Liest einen per Pfad vorgegebener Inhalt einer Text-Datei
///\ [in] path:     Name der Datei, entweder voll qualifiziert
///\ [in] size:     Anzahl Zeichen um zu lesen
///\ Rückgabewert:  Gelesener Inhalt vom Zeiger "buffer"

 char* readFile(const char* path, const int size){

    char* buffer =(char*) malloc(size * sizeof(char));  // Speicherplatz reserviert! Nicht vergessen mit free() freigegeben!
    // path: Name der Datei, entweder voll qualifiziert
    // flag: Bitverknüpfung von Flags (insgesamt 12 definiert) – O_RDONLY: öffnet nur zum Lesen.
    int fd = open(path, O_RDONLY);  // Eine Datei wird zum Lesen geöffnet:: "fd" ist ein Deskriptor einer geöffneten Datei
                                    // Rückgabe: Wenn erfolgreich positiver Wert, der den Dateideskriptor repräsentiert.
    if(fd == -1){   // Fehlerfall: -1. errno kann zur Fehlerauswertung benutzt werden.
        free(buffer);   // Freigabe des reservierten Speicherplatzes
        char* err = "File can't be opened \n";
        // Fehlerausgaben (z.B. eine Datei kann nicht geöffnet werden) sollen auf stderr erfolgen.
        write(STDERR_FILENO, err, sizeof(char)*strlen(err));
    }
    else{
        // Liest maximal "size" Bytes aus "fd" in "buffer" ein. Der Aufrufer ist dafür verantwortlich,
        // dass buf auf einen genügend großen freien Speicher zeigt.
        int ret = read(fd, buffer, size);

        if(ret > 0){ // Erfolg: Rückgabewert Anzahl der gelesenen Bytes
            buffer[ret] = 0x00; // Abschließender null setzen

            int closed = close(fd); // Schließen einer Datei: "fd" ist ein Deskriptor einer geöffneten Datei, die geschlossen werden soll
                                    // Rückgabe: 0 wenn erfolgreich, sonst -1. errno kann zur Fehlerdiagnose genutzt werden
            if(closed == 0){ //Rückgabe: 0 wenn erfolgreich
                // char* out = "\n File closed \n";
                // write(STDOUT_FILENO, out, sizeof(char)*strlen(out));
            }
            else{
                char* err = "Couldn't close file \n";
                write(STDERR_FILENO, err, sizeof(char)*strlen(err));
            }
        }
        else{   // Rückgabewert: -1 im Fehlerfall
             char* err = "Couldn't read file \n";
             write(STDERR_FILENO, err, sizeof(char)*strlen(err));
        }
    }

    return buffer;  // Gelesener Inhalt vom Zeiger "buffer"
 }

// Bildschirmausgabe und Kopieren einer Datei sollen
// in derselben Funktion realisiert werden.
///\ Schreibt einen per Pfad vorgegebener Inhalt einer Text-Datei auf den Bildschir oder in eine Copy-Textdatei
///\ [in] outOpt:        Optionen für die Bildschirmausgabe oder für das Kopieren in eine Datei
///\ [in] path:          Name der zu kopierenden Text-Datei, voll qualifiziert
///\ [in] pathNew:       Name der Kopie der Text-Datei, voll qualifiziert
///\ [in] size:          Anzahl Zeichen um zu schreiben
///\ Rückgabewert:  void
 void printText(const enum OutputOption outOpt, const char* path, const char*pathNew, int size, bool bChange){

    if(outOpt == consoleOut){
        char* buffer = readFile(path, size);  // Datei lesen

        int length = strlen(buffer);
        int half = length/2;

        char *text= (char*) malloc(sizeof(buffer)*sizeof(char));
        int i = half;

        int k = 0;

        while (i>=half && i<length){
            text[k] = buffer[i];
            k++;
            i++;
        }

        int j = 0;

         while (j<half){
             text[k] = buffer[j];
             k++;
             j++;

         }

        write(STDOUT_FILENO, text, 1024);

       //free(buffer);   // Speicher freigeben
       //free(text);     // Speicher freigeben
    }
    else if(outOpt == fileOut){

        int fd = open(path, O_RDONLY);

        if(fd == -1){   // Fehlerfall: -1. errno kann zur Fehlerauswertung benutzt werden.
            char* err = "File can't be opened \n";
            // Fehlerausgaben (z.B. eine Datei kann nicht geöffnet werden) sollen auf stderr erfolgen.
            write(STDERR_FILENO, err, sizeof(char)*strlen(err));
        }
        else{

            char* textNew =(char*) calloc(size, sizeof(char));

            if(bChange)
            {
                lseek(fd, -12, SEEK_END);    // Positioniert den Dateizeiger auf die 10-te Stelle von der Dateiende, ab der aus einer Quelle-Datei gelesen wird
            }

            int ret = read(fd, textNew, size);
/*
char* out1 = "\n\n *** !!!!!!!!!! ***\n\n";
write(STDOUT_FILENO, out1, sizeof(char)*strlen(out1));

     write(STDOUT_FILENO, textNew, sizeof(char)*strlen(textNew));

char* out2 = "\n\n *** !!!!!!!!!!!!! ***\n\n";
write(STDOUT_FILENO, out2, sizeof(char)*strlen(out2));*/


            if( (!pathNew) || (ret == -1) ){   // Fehlerfall: -1. errno kann zur Fehlerauswertung benutzt werden.
                free(textNew);
                char* err = "File can't be opened \n";
                // Fehlerausgaben (z.B. eine Datei kann nicht geöffnet werden) sollen auf stderr erfolgen.
                write(STDERR_FILENO, err, sizeof(char)*strlen(err));

                char* out1 = "\n\n *** File can't be opened ***\n\n";
                 write(STDOUT_FILENO, out1, sizeof(char)*strlen(out1));
            }
            else{
                textNew[ret] = '\0';    // Zeichen "end of string" setzen
                int fdNew = open(pathNew, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);

                if(bChange)
                {
                    lseek(fdNew, 10, SEEK_SET);
                }

                write(fdNew, textNew, sizeof(char)*strlen(textNew));

                //write(STDOUT_FILENO, textNew, sizeof(char)*strlen(textNew));
                //(textNew);  // Speicher freigeben
                int closedNew = close(fdNew);

                if(closedNew == 0){
                    //char* out = "\n File closed \n";
                    //write(STDOUT_FILENO, out, sizeof(char)*strlen(out));
                }
                else{
                    char* err = "Couldn't close file \n";
                    write(STDERR_FILENO, err, sizeof(char)*strlen(err));
                }
            }

            //free(textNew);
        }

        int closed = close(fd);

        if(closed == 0){
            //char* out = "\n File closed \n";
            //write(STDOUT_FILENO, out, sizeof(char)*strlen(out));
        }
        else{
            char* err = "Couldn't close file \n";
            write(STDERR_FILENO, err, sizeof(char)*strlen(err));
        }
    }
    else{
        ; // TODO ...
    }
 }


///\ Schreibt einen per Pfad vorgegebener Inhalt einer Text-Datei auf dem Bildschirn
///\ [in] path:     Name der Datei, entweder voll qualifiziert
///\ [in] size:     Anzahl Zeichen um zu lesen
///\ Rückgabewert:  void
 void printFileScreen(char* path, int size){

    int fd = open(path, O_RDONLY, size);

    if(fd == -1){   // Fehlerfall: -1. errno kann zur Fehlerauswertung benutzt werden.
        char* err = "File can't be opened \n";
        // Fehlerausgaben (z.B. eine Datei kann nicht geöffnet werden) sollen auf stderr erfolgen.
        write(STDERR_FILENO, err, sizeof(char)*strlen(err));
    }
    else{   // Erfolg

        char* buffer = (char*)malloc(size*sizeof(char)); // Speicherplatz reservieren!
        // Liest maximal "size" Bytes aus "fd" in "buffer" ein. Der Aufrufer ist dafür verantwortlich,
        // dass buf auf einen genügend großen freien Speicher zeigt.
        int ret = read(fd, buffer, size);

        if(ret > 0){ // Erfolg: Rückgabewert Anzahl der gelesenen Bytes
            buffer[ret] = '\0';    // Zeichen "end of string" setzen
            write(STDOUT_FILENO, buffer, sizeof(buffer)*strlen(buffer)); // Auf den Bildschirm schreiben: stdout, Standardausgabe

            int closed = close(fd); // Schließen einer Datei: "fd" ist ein Deskriptor einer geöffneten Datei, die geschlossen werden soll
                                    // Rückgabe: 0 wenn erfolgreich, sonst -1. errno kann zur Fehlerdiagnose genutzt werden
            if(closed == 0){
                //char* out = "\n File closed \n";
                //write(STDOUT_FILENO, out, sizeof(char)*strlen(out));
            }
            else{
                char* err = "Couldn't close file \n";
                write(STDERR_FILENO, err, sizeof(char)*strlen(err));
            }
        }
        else{   // Rückgabewert: -1 im Fehlerfall
             free(buffer); // Speicherplatz freigeben!
             char* err = "Couldn't read file \n";
             write(STDERR_FILENO, err, sizeof(char)*strlen(err));
        }
    }

    return;
 }


 int main(int argc, char *argv[])
 {
    char *path = 0;    //"/home/diana/Desktop/POSIX_Datei_Aktivity/Orig.txt";
    char *pathNew = 0; //"/home/diana/Desktop/POSIX_Datei_Aktivity/Ziel.txt";

    // Das Ziel der Operation (Standardausgabe(Bildschirm) oder Zieldatei)
    // wird der Funktion als Parameter übergeben.
     if(3 > argc)
     {
       char* out = "\n Übergen Sie mindestens 2 Argumente:\n[1] woher soll geladen werden;\n[2] wohin soll geladen werden \n";
       write(STDOUT_FILENO, out, sizeof(char)*strlen(out)); // POSIX 1003.1 - man page for strlen (posix section 3P)
                    //printf("");
                    //printf("\n");
        return EXIT_FAILURE;
     }

    path = argv[1];
    pathNew = argv[2];

    // Es sollen keinerlei Beschränkungen über die Größe
    // der zu kopierenden Inhalte getroffen werden
    int size = 2048;

    ///\ #1 Eine Datei wird zum Lesen geöﬀnet; anschließend wird zuerst die zweite Hälfte und
    ///\    dann die erste Hälfte des Dateiinhalts auf dem Bildschirm ausgegeben
    char* out = "\n\n *** Aufgabe Nr 1 ***\n\n";
    write(STDOUT_FILENO, out, sizeof(char)*strlen(out));
    // Lösung #1
    printText(consoleOut, path, 0, size, false);

    ///\ #2 Danach wird der Inhalt der Datei in eine neue Datei kopiert,
    ///\    wobei der Dateiname der Quell- und der Zieldatei dem Programm als Argument übergeben werden kann.
    // Lösung #2
    char* out1 = "\n\n *** Aufgabe Nr 2: Inhalt von Kopie-Textdatei ***\n\n";
    write(STDOUT_FILENO, out1, sizeof(char)*strlen(out1));

    printText(fileOut, path, pathNew, size, false);
    printFileScreen(pathNew, size);

    ///\ #3 Die letzten 10 Zeichen der urspr¨unglichen Datei werden ab der 11. Stelle der neuen Datei kopiert.
    ///\    Das Dateiende der neuen Datei soll jetzt nach den verschobenen Daten sein (also nach dem 21. Zeichen).
    char* out2 = "\n\n *** Aufgabe Nr 3 ***\n\n";
    write(STDOUT_FILENO, out2, sizeof(char)*strlen(out2));
    printText(fileOut, path, pathNew, size, true);

     ///\ #4 Der Inhalt der neuen Datei (Kopie) soll auf dem Bildschirm ausgegeben werden
    char* out3 = "\n\n *** Aufgabe Nr 4 ***\n\n";
    write(STDOUT_FILENO, out3, sizeof(char)*strlen(out3));
    // Lösung #4
    printFileScreen(pathNew, size);

    return 0;
 }
