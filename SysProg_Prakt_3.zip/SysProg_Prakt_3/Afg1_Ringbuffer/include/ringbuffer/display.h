#ifndef DISPLAY_H
#define DISPLAY_H

#include "ringbuffer.h"

void display_status(const ring_buffer *cb);

#endif //DISPLAY_H
