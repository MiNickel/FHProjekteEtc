/*
 * Diese Source File wird fuer diverse Tests benoetigt.
 * NICHT VERAENDERN!
 */
#include "studiverwaltung_mock.h"

IMPLEMENT_FUNCTION_MOCK1( FreeMock, sp_free, void(void*));
