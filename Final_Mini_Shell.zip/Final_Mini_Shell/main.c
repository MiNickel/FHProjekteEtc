#include <stdlib.h>     // void exit(int status);
#include <stdio.h>      // gets()
#include <string.h>     // strsep()
#include <unistd.h>     // pid_t fork(void);
#include <errno.h>      // char* strerror(int);
#include <sys/wait.h>   //pid_t waitpid(pid_t pid, int* stat_loc, int options);

// functions-prototyps: Function Declarations for builtin shell commands
void parseCommand(char* cmd, char** params);
int executeCommand(char** params);
int build_in_cd(char **args);
int build_in_help(char **args);
int build_in_exit(char **args);
int build_in_set(char **args);
int findChar(char* str, int sign);
int num_builtins();

#define MAX_COMMAND_LENGTH 100
#define MAX_NUMBER_OF_PARAMS 10

// List of builtin commands, followed by their corresponding functions.
char *builtin_str[] = {
  "cd",
  "help",
  "exit",
  "set"
};

int main()
{
    char cmd[MAX_COMMAND_LENGTH + 1];
    char* params[MAX_NUMBER_OF_PARAMS + 1];
    printf("******************************************\n");
    printf("            MINDEN_MINI_SHELL");
    printf("\n******************************************\n\n");
    printf("Zum Verlassen der shell  'exit' oder Ctrl+D eingeben.\n\n");
    printf("Es wird auf die Eingabe Ihrer Befehle gewartet !!!\n\n");

    while(1) {
       //user & actual Directory
        char* username = getenv("USER");
        char current_directory[1024];
        getcwd(current_directory, sizeof(current_directory));
        printf("%s@my_shell: %s> ", username, current_directory);

        // Read command from standard input, exit on Ctrl+D
        if(fgets(cmd, sizeof(cmd), stdin) == NULL)
            break;  // exit for error

        // Remove trailing newline character
        if(cmd[strlen(cmd)-1] == '\n') {
            cmd[strlen(cmd)-1] = '\0';
        }

        // Split cmd into array of parameters:Separate command string into program and arguments.
        parseCommand(cmd, params);

        // Execute command: Run parsed command
        if(executeCommand(params) == 0)
            break;  // error at child process
    }
    return EXIT_SUCCESS;
}

// Split cmd into parameters-array
void parseCommand(char* cmd, char** params)
{
    for(int i = 0; i < MAX_NUMBER_OF_PARAMS; i++) {
        params[i] = strsep(&cmd, " ");

        if(params[i] == NULL)
            break;
    }
}

// Execute command:Run the parsed command.
int executeCommand(char** params)
{
//////////// Shell Builtins: START ////////////////////////////
    // if str1 is less than str2 then (ret < 0)
    // if str2 is less than str1 then (ret > 0)
    // if str1 is equal to str2 then (ret == 0)
    if(strcmp(params[0], builtin_str[0]) == 0) // "cd"
    {
        build_in_cd(params);
        return 1;
    }
    else if(strcmp(params[0], builtin_str[1]) == 0) // "help"
    {
        build_in_help(params);
        return 1;
    }
    else if(strcmp(params[0], builtin_str[2]) == 0) // "exit"
    {
        build_in_exit(params);
        return 1;
    }
    else if(strcmp(params[0], builtin_str[3]) == 0) // "set"
    {
        build_in_set(params);
        return 1;
    }
//////////// Shell Builtins: END ////////////////////////////

    // Fork process
    pid_t pid = fork(); // Once fork() returns, actually two processes running concurrently

    // Error
    if (pid == -1) {
        char* error = strerror(errno);
        printf("fork: %s\n", error);
        return 1;
    }
    else if (pid == 0) {        // Child process

        // Execute command of user in this child process
        execvp(params[0], params); // process never returns from an execvp() call (unless there’s an error).

        // Error
        char* error = strerror(errno);
        printf("shell: %s: %s\n", params[0], error);
        return 0;
    }
    else {                         // Parent process

        // Wait for child process to finish
        int childStatus;
        waitpid(pid, &childStatus, 0);
        return 1;
        // The parent process can continue doing other things,
        // and it can even keep tabs on its children, using the system call wait().
    }
}

int num_builtins() {
  return sizeof(builtin_str) / sizeof(char *);
}

//Builtin functions implementations:
int build_in_cd(char **args)
{
  if (args[1] == NULL) {
    fprintf(stderr, "expected argument to \"cd\"\n");
  }
  else {
    if (chdir(args[1]) != 0) {
      perror("builtin cd");
    }
  }
  return 1;
}

int build_in_help(char **args)
{
  int i;
  printf("MESSAGE FROM SHELL:\n");
  printf("Geben Sie den Programmnamen und Argumente ein und drücken Sie die Eingabetaste.\n");
  printf("Folgende built-in Funktionen werden unterstützt:\n");

  for (i = 0; i < num_builtins(); i++) {
    printf("  %s\n", builtin_str[i]);
  }

  printf("Verwenden Sie das man Kommando um andere Informationen zu erhalten.\n");
  return 1;
}

int build_in_exit(char **args)
{
    exit(0);    // void exit(int status);
}

int build_in_set(char **args)
{
 int iPosition = 0;
 int isizeParam = 0;

 for(int i = 1; i < 4; ++i)
 {
    if (args[i] != NULL)
        isizeParam++;
 }

 if (isizeParam == 1)
 {
   if ( args[1] == NULL) {
    fprintf(stderr, "expected argument to \"set\"\n");
  }
  else {
      iPosition = findChar(args[1], '=');

      if(iPosition < (strlen(args[1]) -1))
      {
        if (putenv(args[1]) != 0)
          perror("builtin set");
      }
    }
 }
 else if (isizeParam == 2)
 {
   if ( args[1] == NULL || args[2] == NULL) {
    fprintf(stderr, "expected argument to \"set\"\n");
  }
  else {
      if(findChar(args[1], '=')|| findChar(args[2], '='))
      {
        if (putenv(strcat(args[1],args[2])) != 0)
          perror("builtin set");
      }
    }
 }
 else if (isizeParam == 3)
 {
   if (args[1] == NULL || args[2] == NULL || args[3] == NULL) {
    fprintf(stderr, "expected argument to \"set\"\n");
  }
  else {
      if(findChar(args[1], '=') || findChar(args[2], '=') | findChar(args[3], '='))
      {
        if (putenv(strcat(args[1],args[2])) != 0)
          perror("builtin set");
      }
    }
 }
  return 1;
}

int findChar(char* ZeichenKette, int c)
{
  for (size_t i = 0; i < strlen(ZeichenKette); i++)
      if (ZeichenKette[i] == c)
        return(i);
  // ansonsten 1 zurückgeben
  return(-1);
}

/*
Der Grund:
Zum wechseln des Verzeichnisses muss man die Funktion chdir () verwenden.
Das aktuelle Verzeichnis ist eine Eigenschaft eines Prozesses.
Wenn man ein Programm namens cd geschrieben hat, das das Verzeichnis geändert hat,
würde es nur sein eigenes aktuelles Verzeichnis ändern und dann beenden.
Das aktuelle Verzeichnis des übergeordneten Prozesses wäre unverändert.
Stattdessen muss der Shell-Prozess selbst chdir () ausführen,
damit sein eigenes aktuelles Verzeichnis aktualisiert wird.
Wenn es dann untergeordnete Prozesse startet, werden sie auch dieses Verzeichnis erben.

Ähnlich,wenn es ein Programm namens exit gäbe, könnte es die Shell,
die es aufgerufen hat, nicht verlassen.
Dieser Befehl muss auch in die Shell eingebaut werden.
Außerdem werden die meisten Shells durch Ausführen von Konfigurationsskripten wie ~ / .bashrc konfiguriert.
Diese Skripte verwenden Befehle, die den Betrieb der Shell ändern.
Diese Befehle können nur die Shell-Operation ändern, wenn sie innerhalb der Shell selbst implementiert wurden.
*/

